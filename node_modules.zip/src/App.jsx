// App.jsx
import React, { useEffect, useState } from "react";

const API_BASE = "http://localhost:5000";

function apiFetch(path, token, opts = {}) {
  const headers = opts.headers || {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  headers["Content-Type"] = headers["Content-Type"] || "application/json";
  return fetch(API_BASE + path, { ...opts, headers }).then(async (r) => {
    const text = await r.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch (e) {
      json = text;
    }
    if (!r.ok) throw { status: r.status, body: json };
    return json;
  });
}

function useAuth() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [role, setRole] = useState(localStorage.getItem("role"));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("user") || "null"));

  useEffect(() => {
    localStorage.setItem("token", token || "");
    localStorage.setItem("role", role || "");
    localStorage.setItem("user", user ? JSON.stringify(user) : "");
  }, [token, role, user]);

  const login = (token, role, userObj) => {
    setToken(token);
    setRole(role);
    setUser(userObj || null);
  };
  const logout = () => {
    setToken(null);
    setRole(null);
    setUser(null);
    localStorage.clear();
  };

  return { token, role, user, login, logout };
}

function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [err, setErr] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setErr(null);
    try {
      const res = await fetch(API_BASE + "/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, role }),
      });
      const json = await res.json();
      if (!res.ok) throw json;
      onLogin(json.token, json.role, { ...json });
    } catch (err) {
      setErr(err?.message || JSON.stringify(err));
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow p-4 mx-auto" style={{ maxWidth: 450 }}>
        <h3 className="text-center mb-3">Login</h3>

        <form onSubmit={submit}>
          <label className="form-label">Role</label>
          <select className="form-select mb-3" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="student">Student (roll number)</option>
            <option value="guide">Guide (guide_name)</option>
            <option value="admin">Admin (username)</option>
          </select>

          <input
            className="form-control mb-3"
            placeholder="username / roll number"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <input
            className="form-control mb-3"
            placeholder="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button className="btn btn-primary w-100">Login</button>

          {err && <div className="alert alert-danger mt-3">{err}</div>}
        </form>

        <p className="text-muted small mt-3">
          Tip: admin@123/admin123 | Staff Guide/guide123 | R001/student123
        </p>
      </div>
    </div>
  );
}

/* ----------------------- Student Dashboard ----------------------- */
function StudentDashboard({ token, user }) {
  const [projects, setProjects] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const json = await apiFetch("/students/me/projects", token);
      setProjects(json.projects || []);
    } catch (err) {
      alert("Failed to load projects");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  return (
    <div className="container mt-4">
      <h2>Student Dashboard — {user?.name || user?.roll_number}</h2>

      <button className="btn btn-secondary my-3" onClick={fetchProjects}>
        Refresh
      </button>

      {loading && <div className="spinner-border" />}

      {!loading &&
        projects &&
        projects.map((p) => (
          <div className="card p-3 mb-3 border-primary" key={p.project_id}>
            <h4>
              {p.title} <span className="text-muted">({p.project_type})</span>
            </h4>
            <p>{p.description}</p>
            <p>
              <strong>Guide:</strong> {p.guide_name}
            </p>
            <p>
              <strong>Department:</strong> {p.department}
            </p>

            {p.team?.length > 0 && (
              <>
                <strong>Team</strong>
                <ul>{p.team.map((m) => <li key={m.student_id}>{m.roll_number} — {m.name}</li>)}</ul>
              </>
            )}

            {p.internship && (
              <p className="text-success">
                <strong>Internship:</strong> {p.internship.company_name} — {p.internship.domain} ({p.internship.duration})
              </p>
            )}
          </div>
        ))}
    </div>
  );
}

/* ----------------------- Guide Dashboard ----------------------- */
function GuideDashboard({ token, user }) {
  const [projects, setProjects] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [department_id, setDeptId] = useState("");
  const [member_type, setMemberType] = useState("individual");
  const [project_type, setProjectType] = useState("semester");
  const [studentIdsCsv, setStudentIdsCsv] = useState("");
  const [internForm, setInternForm] = useState({
    projectId: "",
    student_id: "",
    company_name: "",
    duration: "",
    domain: "",
  });

  const fetchMyProjects = async () => {
    try {
      const json = await apiFetch("/guides/me/projects", token);
      setProjects(json.projects || []);
    } catch {
      alert("Error fetching projects");
    }
  };

  useEffect(() => {
    fetchMyProjects();
  }, []);

  const createProject = async () => {
    if (!title) return alert("Title required");
    try {
      await apiFetch("/guides/projects", token, {
        method: "POST",
        body: JSON.stringify({ title, description, department_id, member_type, project_type }),
      });
      alert("Project created");
      setTitle("");
      setDescription("");
      fetchMyProjects();
    } catch {
      alert("Create failed");
    }
  };

  const addStudents = async (projectId) => {
    const arr = studentIdsCsv
      .split(",")
      .map((x) => Number(x.trim()))
      .filter(Boolean);

    if (!arr.length) return alert("Provide IDs CSV");

    try {
      await apiFetch(`/guides/projects/${projectId}/add-students`, token, {
        method: "POST",
        body: JSON.stringify({ student_ids: arr }),
      });
      alert("Students added");
      setStudentIdsCsv("");
      fetchMyProjects();
    } catch {
      alert("Add failed");
    }
  };

  const updateInternship = async () => {
    const { projectId, student_id, company_name, duration, domain } = internForm;
    if (!projectId || !student_id) return alert("Required fields");
    try {
      await apiFetch(`/guides/projects/${projectId}/internship`, token, {
        method: "POST",
        body: JSON.stringify({ student_id: Number(student_id), company_name, duration, domain }),
      });
      alert("Updated");
      setInternForm({ projectId: "", student_id: "", company_name: "", duration: "", domain: "" });
      fetchMyProjects();
    } catch {
      alert("Intern update failed");
    }
  };

  return (
    <div className="container mt-4">
      <h2>Guide Dashboard — {user?.name}</h2>

      <div className="card p-3 mt-3 shadow-sm">
        <h4>Create Project</h4>
        <input className="form-control mb-2" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea className="form-control mb-2" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
        <select className="form-select mb-2" value={member_type} onChange={(e) => setMemberType(e.target.value)}>
          <option value="individual">Individual</option>
          <option value="group">Group</option>
        </select>
        <select className="form-select mb-2" value={project_type} onChange={(e) => setProjectType(e.target.value)}>
          <option value="semester">Semester</option>
          <option value="final_year">Final Year</option>
        </select>
        <input className="form-control mb-2" placeholder="Department ID" value={department_id} onChange={(e) => setDeptId(e.target.value)} />
        <button className="btn btn-primary" onClick={createProject}>Create</button>
      </div>

      <div className="card p-3 mt-4">
        <h4>Add Students</h4>
        <small>enter id CSV (1,2,3)</small>
        <input className="form-control mb-2" value={studentIdsCsv} onChange={(e) => setStudentIdsCsv(e.target.value)} />
        {projects.map((p) => (
          <div className="border rounded p-2 mb-2" key={p.project_id}>
            <strong>{p.title}</strong> (id: {p.project_id})
            <button className="btn btn-sm btn-success ms-3" onClick={() => addStudents(p.project_id)}>
              Add
            </button>
          </div>
        ))}
      </div>

      <div className="card p-3 mt-4">
        <h4>Internship</h4>
        <input className="form-control mb-2" placeholder="projectId" value={internForm.projectId} onChange={(e) => setInternForm({ ...internForm, projectId: e.target.value })} />
        <input className="form-control mb-2" placeholder="student_id" value={internForm.student_id} onChange={(e) => setInternForm({ ...internForm, student_id: e.target.value })} />
        <input className="form-control mb-2" placeholder="company" value={internForm.company_name} onChange={(e) => setInternForm({ ...internForm, company_name: e.target.value })} />
        <input className="form-control mb-2" placeholder="duration" value={internForm.duration} onChange={(e) => setInternForm({ ...internForm, duration: e.target.value })} />
        <input className="form-control mb-2" placeholder="domain" value={internForm.domain} onChange={(e) => setInternForm({ ...internForm, domain: e.target.value })} />
        <button className="btn btn-warning" onClick={updateInternship}>
          Update
        </button>
      </div>

      <h3 className="mt-4">My Projects</h3>
      {projects.map((p) => (
        <div className="card p-3 mb-3 border-info" key={p.project_id}>
          <h4>{p.title}</h4>
          <p>{p.description}</p>
          <ul>{p.team?.map((m) => <li key={m.student_id}>{m.roll_number} — {m.name}</li>)}</ul>
        </div>
      ))}
    </div>
  );
}

/* ----------------------- Admin Dashboard ----------------------- */
function AdminDashboard({ token }) {
  const [stats, setStats] = useState(null);
  const [students, setStudents] = useState([]);
  const [guides, setGuides] = useState([]);
  const [projects, setProjects] = useState([]);
  const [newDeptName, setNewDeptName] = useState("");
  const [newStudent, setNewStudent] = useState({
    roll_number: "",
    name: "",
    department_id: "",
    batch: "",
    password: "",
  });
  const [newGuide, setNewGuide] = useState({
    guide_name: "",
    department_id: "",
    designation: "",
    password: "",
  });

  const fetchStats = async () => {
    try {
      const j = await apiFetch("/admin/stats", token);
      setStats(j);
    } catch {
      alert("error");
    }
  };
  const fetchStudents = async () => {
    const j = await apiFetch("/admin/students", token);
    setStudents(j.students || []);
  };
  const fetchGuides = async () => {
    const j = await apiFetch("/admin/guides", token);
    setGuides(j.guides || []);
  };
  const fetchProjects = async () => {
    const j = await apiFetch("/admin/projects", token);
    setProjects(j.projects || []);
  };

  useEffect(() => {
    fetchStats();
    fetchStudents();
    fetchGuides();
    fetchProjects();
  }, []);

  const addDepartment = async () => {
    if (!newDeptName) return alert("required");
    await apiFetch("/admin/departments", token, { method: "POST", body: JSON.stringify({ name: newDeptName }) });
    alert("added");
    setNewDeptName("");
    fetchStats();
  };

  const createStudent = async () => {
    if (!newStudent.roll_number || !newStudent.name || !newStudent.password) return alert("missing");
    await apiFetch("/admin/students", token, { method: "POST", body: JSON.stringify(newStudent) });
    alert("created");
    setNewStudent({ roll_number: "", name: "", department_id: "", batch: "", password: "" });
    fetchStudents();
  };

  const createGuide = async () => {
    if (!newGuide.guide_name || !newGuide.password) return alert("missing");
    await apiFetch("/admin/guides", token, { method: "POST", body: JSON.stringify(newGuide) });
    alert("guide created");
    setNewGuide({ guide_name: "", department_id: "", designation: "", password: "" });
    fetchGuides();
  };

  return (
    <div className="container mt-4">
      <h2>Admin Panel</h2>

      <div className="card p-3 mt-3">
        <h4>Stats</h4>
        {stats && (
          <>
            <p>Total Students: {stats.total_students}</p>
            <p>Total Guides: {stats.total_guides}</p>
            <p>Total Projects: {stats.total_projects}</p>

            <h5>Final Projects:</h5>
            {stats.finalProjects?.map((p) => (
              <div className="border p-2 mb-2" key={p.project_id}>
                <strong>{p.title}</strong> — {p.guide_name}
              </div>
            ))}
          </>
        )}
      </div>

      <div className="card p-3 mt-3">
        <h4>Add Department</h4>
        <input className="form-control mb-2" value={newDeptName} onChange={(e) => setNewDeptName(e.target.value)} />
        <button className="btn btn-primary" onClick={addDepartment}>Add</button>
      </div>

      <div className="card p-3 mt-3">
        <h4>Create Student</h4>
        {["roll_number", "name", "department_id", "batch", "password"].map((f) => (
          <input
            key={f}
            className="form-control mb-2"
            placeholder={f}
            value={newStudent[f]}
            type={f === "password" ? "password" : "text"}
            onChange={(e) => setNewStudent({ ...newStudent, [f]: e.target.value })}
          />
        ))}
        <button className="btn btn-success" onClick={createStudent}>Create</button>
      </div>

      <div className="card p-3 mt-3">
        <h4>Create Guide</h4>
        {["guide_name", "department_id", "designation", "password"].map((f) => (
          <input
            key={f}
            className="form-control mb-2"
            placeholder={f}
            type={f === "password" ? "password" : "text"}
            value={newGuide[f]}
            onChange={(e) => setNewGuide({ ...newGuide, [f]: e.target.value })}
          />
        ))}
        <button className="btn btn-success" onClick={createGuide}>Create</button>
      </div>

      <h4 className="mt-4">All Students</h4>
      <ul className="list-group mb-4">
        {students.map((s) => (
          <li key={s.student_id} className="list-group-item">
            {s.roll_number} — {s.name}
          </li>
        ))}
      </ul>

      <h4>All Guides</h4>
      <ul className="list-group mb-4">
        {guides.map((g) => (
          <li key={g.guide_id} className="list-group-item">
            {g.guide_name} — {g.designation}
          </li>
        ))}
      </ul>

      <h4>All Projects</h4>
      {projects.map((p) => (
        <div className="card p-2 mb-2" key={p.project_id}>
          <strong>{p.title}</strong> — {p.project_type}
        </div>
      ))}
    </div>
  );
}

/* ----------------------- Main App ----------------------- */
export default function App() {
  const auth = useAuth();
  if (!auth.token) return <Login onLogin={auth.login} />;

  return (
    <>
      <nav className="navbar navbar-dark bg-dark px-3">
        <span className="navbar-brand">Student Project Repo</span>
        <div className="d-flex">
          <span className="text-white me-3">{auth.role}</span>
          <button className="btn btn-danger btn-sm" onClick={auth.logout}>Logout</button>
        </div>
      </nav>

      {auth.role === "student" && <StudentDashboard token={auth.token} user={auth.user} />}
      {auth.role === "guide" && <GuideDashboard token={auth.token} user={auth.user} />}
      {auth.role === "admin" && <AdminDashboard token={auth.token} />}
    </>
  );
}
